import tkinter as tk
from tkinter import filedialog, scrolledtext, messagebox
from PIL import Image, ImageTk
import ollama
import threading
import json
import re
import random

# --- Modern Minimalist Theme ---
BG_COLOR = "#18181B"
PANEL_BG = "#27272A"
FG_COLOR = "#FAFAFA"
ACCENT_COLOR = "#3B82F6"
PLAYER_COLOR = "#10B981"
INVENTORY_COLOR = "#F59E0B"
WARNING_COLOR = "#EF4444" 
AUTOPLAY_COLOR = "#A855F7"
XP_COLOR = "#06B6D4" # Cyan for XP
FONT_MAIN = ("Helvetica", 11)
FONT_TITLE = ("Helvetica", 16, "bold")
FONT_LABEL = ("Helvetica", 10, "bold")

class RPGSetup:
    def __init__(self, root, on_start_callback, on_load_callback):
        self.root = root
        self.on_start = on_start_callback
        self.on_load = on_load_callback
        self.player_avatar_path = None
        self.comp_avatar_path = None

        self.frame = tk.Frame(root, bg=BG_COLOR)
        self.frame.pack(expand=True, fill="both")
        
        self.canvas = tk.Canvas(self.frame, bg=BG_COLOR, highlightthickness=0)
        self.scrollbar = tk.Scrollbar(self.frame, orient="vertical", command=self.canvas.yview)
        self.container = tk.Frame(self.canvas, bg=BG_COLOR, padx=40, pady=20)

        self.container.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.container, anchor="nw", width=800)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        tk.Label(self.container, text="New Adventure Setup", bg=BG_COLOR, fg=FG_COLOR, font=FONT_TITLE).pack(pady=(0, 20))

        top_frame = tk.Frame(self.container, bg=BG_COLOR)
        top_frame.pack(fill="x")
        
        tk.Label(top_frame, text="Ollama Model:", bg=BG_COLOR, fg=ACCENT_COLOR, font=FONT_LABEL).grid(row=0, column=0, sticky="w")
        self.model_entry = tk.Entry(top_frame, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, width=15)
        self.model_entry.insert(0, "llama3")
        self.model_entry.grid(row=1, column=0, padx=(0, 10), pady=(0, 10))

        tk.Label(top_frame, text="Your Name:", bg=BG_COLOR, fg=PLAYER_COLOR, font=FONT_LABEL).grid(row=0, column=1, sticky="w")
        self.player_name_entry = tk.Entry(top_frame, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, width=20)
        self.player_name_entry.grid(row=1, column=1, padx=(0, 10), pady=(0, 10))

        tk.Label(top_frame, text="Companion Name:", bg=BG_COLOR, fg=ACCENT_COLOR, font=FONT_LABEL).grid(row=0, column=2, sticky="w")
        self.comp_name_entry = tk.Entry(top_frame, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, width=20)
        self.comp_name_entry.grid(row=1, column=2, pady=(0, 10))

        # --- Stat Allocation ---
        stat_frame = tk.Frame(self.container, bg=BG_COLOR)
        stat_frame.pack(fill="x", pady=(0, 10))
        tk.Label(stat_frame, text="Stats (1-20):", bg=BG_COLOR, fg=XP_COLOR, font=FONT_LABEL).grid(row=0, column=0, sticky="w", padx=(0,10))
        
        self.stats_entries = {}
        for i, stat in enumerate(["STR", "DEX", "INT", "CHA"]):
            tk.Label(stat_frame, text=stat, bg=BG_COLOR, fg=FG_COLOR, font=FONT_LABEL).grid(row=0, column=1+(i*2), sticky="e")
            entry = tk.Entry(stat_frame, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, width=3)
            entry.insert(0, "10") # Default stat
            entry.grid(row=0, column=2+(i*2), padx=(5, 15))
            self.stats_entries[stat] = entry

        tk.Label(self.container, text="Your Lore (Who are you?):", bg=BG_COLOR, fg=PLAYER_COLOR, font=FONT_LABEL).pack(anchor="w")
        self.player_lore = tk.Text(self.container, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, height=2)
        self.player_lore.pack(fill="x", pady=(0, 10))

        tk.Label(self.container, text="Companion Lore/Personality:", bg=BG_COLOR, fg=ACCENT_COLOR, font=FONT_LABEL).pack(anchor="w")
        self.comp_lore = tk.Text(self.container, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, height=2)
        self.comp_lore.pack(fill="x", pady=(0, 10))

        tk.Label(self.container, text="Adventure Context:", bg=BG_COLOR, fg=ACCENT_COLOR, font=FONT_LABEL).pack(anchor="w")
        self.context = tk.Text(self.container, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, height=2)
        self.context.pack(fill="x", pady=(0, 10))

        tk.Label(self.container, text="Custom AI Rules (What it should/shouldn't do):", bg=BG_COLOR, fg=WARNING_COLOR, font=FONT_LABEL).pack(anchor="w")
        self.custom_rules = tk.Text(self.container, bg=PANEL_BG, fg=FG_COLOR, font=FONT_MAIN, relief="flat", insertbackground=FG_COLOR, height=2)
        self.custom_rules.insert("1.0", "Keep the tone serious. Do not use magic.") 
        self.custom_rules.pack(fill="x", pady=(0, 10))

        self.luck_var = tk.BooleanVar(value=True)
        tk.Checkbutton(self.container, text="Enable Luck Mode (d20 System)", variable=self.luck_var, bg=BG_COLOR, fg=INVENTORY_COLOR, selectcolor=PANEL_BG, activebackground=BG_COLOR, font=FONT_LABEL).pack(anchor="w")

        self.ai_control_var = tk.BooleanVar(value=False)
        tk.Checkbutton(self.container, text="Enable AI Auto-Play (AI controls your character)", variable=self.ai_control_var, bg=BG_COLOR, fg=AUTOPLAY_COLOR, selectcolor=PANEL_BG, activebackground=BG_COLOR, font=FONT_LABEL).pack(anchor="w", pady=(0, 10))

        btn_frame = tk.Frame(self.container, bg=BG_COLOR)
        btn_frame.pack(pady=20)

        self.btn_upload_player = tk.Button(btn_frame, text="Upload Your PFP", bg=PANEL_BG, fg=PLAYER_COLOR, activebackground=PLAYER_COLOR, font=FONT_MAIN, command=self.upload_player_avatar, relief="flat", padx=10, pady=5)
        self.btn_upload_player.pack(side="left", padx=5)

        self.btn_upload_comp = tk.Button(btn_frame, text="Upload Comp PFP", bg=PANEL_BG, fg=ACCENT_COLOR, activebackground=ACCENT_COLOR, font=FONT_MAIN, command=self.upload_comp_avatar, relief="flat", padx=10, pady=5)
        self.btn_upload_comp.pack(side="left", padx=5)

        self.btn_start = tk.Button(btn_frame, text="Start Game", bg=ACCENT_COLOR, fg=FG_COLOR, activebackground=FG_COLOR, activeforeground=BG_COLOR, font=FONT_MAIN, command=self.start_game, relief="flat", padx=10, pady=5)
        self.btn_start.pack(side="left", padx=20)

        self.btn_load = tk.Button(btn_frame, text="Load Save", bg=PANEL_BG, fg=FG_COLOR, activebackground=ACCENT_COLOR, font=FONT_MAIN, command=self.load_game, relief="flat", padx=10, pady=5)
        self.btn_load.pack(side="left", padx=5)

    def upload_player_avatar(self):
        filepath = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.gif")])
        if filepath:
            self.player_avatar_path = filepath
            self.btn_upload_player.config(text="Your PFP Loaded")

    def upload_comp_avatar(self):
        filepath = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.gif")])
        if filepath:
            self.comp_avatar_path = filepath
            self.btn_upload_comp.config(text="Comp PFP Loaded")

    def start_game(self):
        party = [{
            "name": self.comp_name_entry.get().strip(),
            "personality": self.comp_lore.get("1.0", "end-1c").strip(),
            "avatar_path": self.comp_avatar_path
        }]

        # Catch stats safely
        stats_data = {}
        for stat, entry in self.stats_entries.items():
            try:
                stats_data[stat] = int(entry.get())
            except ValueError:
                stats_data[stat] = 10

        data = {
            "model_name": self.model_entry.get().strip(),
            "player_name": self.player_name_entry.get().strip(),
            "player_lore": self.player_lore.get("1.0", "end-1c").strip(),
            "player_avatar_path": self.player_avatar_path,
            "context": self.context.get("1.0", "end-1c").strip(),
            "custom_rules": self.custom_rules.get("1.0", "end-1c").strip(),
            "party": party,
            "inventory": {},
            "max_hp": 100,
            "current_hp": 100,
            "level": 1,          
            "xp": 0,             
            "stats": stats_data, 
            "messages": [],
            "luck_mode": self.luck_var.get(),
            "ai_control": self.ai_control_var.get()
        }

        if not data["model_name"] or not data["player_name"] or not party[0]["name"] or not self.player_avatar_path or not self.comp_avatar_path:
            messagebox.showerror("Error", "Please fill all names and upload both avatars!")
            return

        self.frame.destroy()
        self.on_start(data)

    def load_game(self):
        filepath = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json")])
        if filepath:
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    # Backwards compatibility for older saves
                    if "current_hp" not in data:
                        data["max_hp"] = 100
                        data["current_hp"] = 100
                    if "level" not in data:
                        data["level"] = 1
                        data["xp"] = 0
                        data["stats"] = {"STR": 10, "DEX": 10, "INT": 10, "CHA": 10}
                self.frame.destroy()
                self.on_load(data)
            except Exception as e:
                messagebox.showerror("Load Error", f"Failed to load save: {e}")

class RPGGame:
    def __init__(self, root, data, is_loaded=False):
        self.root = root
        self.data = data
        self.image_references = [] 
        self.player_photo = None   
        
        if not is_loaded:
            stats_string = f"STR: {data['stats']['STR']} | DEX: {data['stats']['DEX']} | INT: {data['stats']['INT']} | CHA: {data['stats']['CHA']}"
            system_instructions = (
                f"You are the Game Master of a text-based RPG.\n"
                f"Player Name: {data.get('player_name')}\n"
                f"Player Lore: {data.get('player_lore')}\n"
                f"Player Stats: {stats_string} (Use these to judge if a roll is successful based on the action)\n"
                f"Current Party: {', '.join([m['name'] for m in data['party']])}\n"
                f"Context: {data.get('context')}\n"
                f"STRICT CUSTOM RULES: {data.get('custom_rules', 'None')}\n\n"
                "SYSTEM RULES:\n"
                "1. Drive the story forward concisely (3-5 sentences). NEVER break character, and NEVER apologize as an AI.\n"
                "2. DIALOGUE: When ANY character speaks, use: [Name]: 'Dialogue'.\n"
                "3. NEW PARTY: If an NPC joins permanently, use: [ADD_PARTY: CharacterName | 3-word personality]. Put this tag at the VERY END of your response.\n"
                "4. INVENTORY: If the player gains/loses items or money, use: [ITEM: ItemName | +Amount] or [ITEM: ItemName | -Amount]. Put this tag at the VERY END.\n"
                "5. HEALTH: The player has a max of 100 HP. If they take damage or heal, use: [HP: -Amount] or [HP: +Amount]. Put this tag at the VERY END.\n"
                "6. PROGRESSION: Reward the player with XP for defeating foes, solving puzzles, or great roleplay using: [XP: +Amount]. Put this tag at the VERY END.\n"
                "7. LUCK MODE: If the prompt ends with [Roll: X/20], use that number AND the player's Stats to determine success. 1 is catastrophic, 20 is perfect."
            )
            
            if data.get("ai_control"):
                system_instructions += "\n8. AI AUTO-PLAY: You are controlling the player character AND their companions. Narrate their collective actions directly to advance the story. DO NOT explain your reasoning."

            self.data["messages"] = [
                {"role": "system", "content": system_instructions},
                {"role": "assistant", "content": "The stage is set. Let the adventure begin."}
            ]

        self.setup_gui()
        self.render_party() 
        self.render_inventory()
        
        if is_loaded:
            for msg in self.data["messages"]:
                if msg["role"] == "user":
                    clean_msg = re.sub(r' \[Roll: \d+/20\]', '', msg["content"])
                    # Hide the internal level/XP update ping from the UI
                    clean_msg = re.sub(r'\[System Note: Player is currently Level \d+ with \d+/100 XP\.\]\n', '', clean_msg)
                    self.append_text(clean_msg, is_player=True)
                elif msg["role"] == "assistant":
                    self.append_text(msg["content"], is_player=False)
            self.append_text("SYSTEM: Save loaded successfully.", is_player=False, is_system=True)
            if self.data["current_hp"] <= 0:
                self.trigger_game_over()
        else:
            start_prompt = "The adventure begins. Describe the starting location, invent a local currency, and give me 10 units of it. You MUST use the exact tag [ITEM: CurrencyName | +10] in this very first response so my inventory updates."
            self.append_text("SYSTEM: AI is building the world...", is_player=False, is_system=True)
            
            self.send_btn.config(state="disabled")
            self.entry_box.config(state="disabled")
            if hasattr(self, 'action_dropdown'):
                self.action_dropdown.config(state="disabled")
            
            threading.Thread(target=self.send_to_ai, args=(start_prompt,)).start()

    def setup_gui(self):
        self.left_panel_base = tk.Frame(self.root, bg=PANEL_BG, width=220)
        self.left_panel_base.pack(side="left", fill="y")
        self.left_panel_base.pack_propagate(False)

        self.player_frame = tk.Frame(self.left_panel_base, bg=BG_COLOR, pady=10, bd=1, relief="flat")
        self.player_frame.pack(fill="x", padx=10, pady=(10, 5))
        
        tk.Label(self.player_frame, text="PLAYER", bg=BG_COLOR, fg=PLAYER_COLOR, font=FONT_LABEL).pack()
        
        try:
            img = Image.open(self.data["player_avatar_path"]).resize((80, 80), Image.Resampling.LANCZOS)
            self.player_photo = ImageTk.PhotoImage(img)
            tk.Label(self.player_frame, image=self.player_photo, bg=BG_COLOR).pack(pady=5)
        except:
            pass
            
        tk.Label(self.player_frame, text=self.data["player_name"], bg=BG_COLOR, fg=FG_COLOR, font=FONT_TITLE).pack()
        
        self.hp_label = tk.Label(self.player_frame, text=f"HP: {self.data['current_hp']}/{self.data['max_hp']}", bg=BG_COLOR, fg=WARNING_COLOR, font=("Helvetica", 11, "bold"))
        self.hp_label.pack(pady=(5, 0))

        self.lvl_label = tk.Label(self.player_frame, text=f"Lv. {self.data['level']} | XP: {self.data['xp']}/100", bg=BG_COLOR, fg=XP_COLOR, font=("Helvetica", 10, "bold"))
        self.lvl_label.pack()

        stats_text = f"STR: {self.data['stats']['STR']} | DEX: {self.data['stats']['DEX']}\nINT: {self.data['stats']['INT']} | CHA: {self.data['stats']['CHA']}"
        tk.Label(self.player_frame, text=stats_text, bg=BG_COLOR, fg="#A1A1AA", font=("Helvetica", 9)).pack(pady=(5, 0))

        tk.Label(self.left_panel_base, text="INVENTORY", bg=PANEL_BG, fg=INVENTORY_COLOR, font=FONT_LABEL).pack(pady=(15, 0))
        self.inventory_listbox = tk.Listbox(self.left_panel_base, bg=BG_COLOR, fg=FG_COLOR, font=("Helvetica", 10), relief="flat", height=4, selectbackground=ACCENT_COLOR)
        self.inventory_listbox.pack(fill="x", padx=10, pady=(0, 10))

        tk.Frame(self.left_panel_base, bg=BG_COLOR, height=2).pack(fill="x", padx=10, pady=5)

        tk.Label(self.left_panel_base, text="PARTY MEMBERS", bg=PANEL_BG, fg=ACCENT_COLOR, font=FONT_LABEL).pack(pady=5)
        
        self.canvas = tk.Canvas(self.left_panel_base, bg=PANEL_BG, highlightthickness=0)
        self.scrollbar = tk.Scrollbar(self.left_panel_base, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=PANEL_BG)

        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw", width=200)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.pack(side="top", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        btn_save = tk.Button(self.left_panel_base, text="Save Game", bg=BG_COLOR, fg=FG_COLOR, activebackground=ACCENT_COLOR, font=FONT_MAIN, relief="flat", command=self.save_game)
        btn_save.pack(side="bottom", fill="x", pady=10, padx=10)

        self.right_panel = tk.Frame(self.root, bg=BG_COLOR)
        self.right_panel.pack(side="right", fill="both", expand=True)

        self.text_area = scrolledtext.ScrolledText(self.right_panel, bg=BG_COLOR, fg=FG_COLOR, font=FONT_MAIN, wrap="word", insertbackground=FG_COLOR, relief="flat", padx=20, pady=20)
        self.text_area.pack(fill="both", expand=True)
        self.text_area.config(state="disabled")

        self.input_frame = tk.Frame(self.right_panel, bg=PANEL_BG, padx=10, pady=10)
        self.input_frame.pack(fill="x")

        self.action_type_var = tk.StringVar(value="Do")
        self.action_dropdown = tk.OptionMenu(self.input_frame, self.action_type_var, "Say", "Do")
        self.action_dropdown.config(bg=BG_COLOR, fg=FG_COLOR, font=FONT_MAIN, relief="flat", activebackground=ACCENT_COLOR, activeforeground=FG_COLOR, highlightthickness=0)
        self.action_dropdown["menu"].config(bg=BG_COLOR, fg=FG_COLOR, font=FONT_MAIN)
        self.action_dropdown.pack(side="left", padx=(0, 10))

        self.entry_box = tk.Entry(self.input_frame, bg=BG_COLOR, fg=FG_COLOR, font=FONT_MAIN, insertbackground=FG_COLOR, relief="flat")
        self.entry_box.pack(side="left", fill="x", expand=True, ipady=8, padx=(0, 10))
        self.entry_box.bind("<Return>", lambda event: self.handle_input())

        self.send_btn = tk.Button(self.input_frame, text="Send", bg=ACCENT_COLOR, fg=FG_COLOR, activebackground=FG_COLOR, activeforeground=BG_COLOR, font=FONT_MAIN, command=self.handle_input, relief="flat", padx=15)
        self.send_btn.pack(side="right")

        if self.data.get("ai_control"):
            self.action_dropdown.config(state="disabled")
            self.entry_box.insert(0, "(AI Auto-Play Enabled - Sit back and click Next Turn)")
            self.entry_box.config(state="disabled")
            self.send_btn.config(text="Next Turn", bg=AUTOPLAY_COLOR)

    def update_vitals_display(self, damage_taken=False, leveled_up=False):
        self.hp_label.config(text=f"HP: {self.data['current_hp']}/{self.data['max_hp']}")
        self.lvl_label.config(text=f"Lv. {self.data['level']} | XP: {self.data['xp']}/100")
        
        if leveled_up:
            self.append_text(f"*** LEVEL UP! You are now Level {self.data['level']}! Max HP increased! ***", is_system=True)

        if damage_taken:
            self.append_text("*** You took damage! ***", is_system=True)
        
        if self.data["current_hp"] <= 0:
            self.data["current_hp"] = 0
            self.hp_label.config(text=f"HP: 0/{self.data['max_hp']}", fg="#7F1D1D") 
            self.trigger_game_over()

    def trigger_game_over(self):
        self.append_text("\n==================================\n        YOU HAVE DIED\n        GAME OVER\n==================================", is_system=True)
        self.send_btn.config(state="disabled")
        self.entry_box.config(state="disabled")
        self.action_dropdown.config(state="disabled")

    def render_inventory(self):
        self.inventory_listbox.delete(0, tk.END)
        if not self.data.get("inventory"):
            self.inventory_listbox.insert(tk.END, " (Empty)")
            return
            
        for item, count in self.data["inventory"].items():
            self.inventory_listbox.insert(tk.END, f" {count}x {item}")

    def render_party(self):
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        self.image_references.clear()

        for member in self.data["party"]:
            card = tk.Frame(self.scrollable_frame, bg=BG_COLOR, pady=10, bd=1, relief="flat")
            card.pack(fill="x", padx=10, pady=5)
            
            try:
                img = Image.open(member["avatar_path"]).resize((60, 60), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self.image_references.append(photo) 
                tk.Label(card, image=photo, bg=BG_COLOR).pack()
            except:
                pass
                
            tk.Label(card, text=member["name"], bg=BG_COLOR, fg=FG_COLOR, font=("Helvetica", 11, "bold")).pack()
            tk.Label(card, text=member["personality"], bg=BG_COLOR, fg=ACCENT_COLOR, font=("Helvetica", 9), wraplength=150).pack()

    def append_text(self, text, is_player=False, is_system=False, roll=None):
        self.text_area.config(state="normal")
        if is_player:
            roll_text = f" (🎲 Rolled: {roll})" if roll else ""
            self.text_area.insert("end", f"\n[{self.data['player_name']}]: {text}{roll_text}\n", "player")
            self.text_area.tag_config("player", foreground=PLAYER_COLOR, font=("Helvetica", 11, "bold"))
        elif is_system:
            self.text_area.insert("end", f"\n{text}\n", "system")
            self.text_area.tag_config("system", foreground="#FBBF24", font=("Helvetica", 10, "italic"))
        else:
            parts = re.split(r'(\[.*?\]:)', f"\n{text}\n\n")
            for part in parts:
                if re.match(r'\[.*?\]:', part):
                    self.text_area.insert("end", part, "speaker")
                    self.text_area.tag_config("speaker", foreground=ACCENT_COLOR, font=("Helvetica", 11, "bold"))
                else:
                    self.text_area.insert("end", part)

        self.text_area.yview("end")
        self.text_area.config(state="disabled")

    def handle_input(self):
        self.send_btn.config(state="disabled")

        if self.data.get("ai_control"):
            user_text = "Continue the story. Narrate the next actions and dialogue for my character AND my companion(s) directly. Do not explain your reasoning or mention that you are following rules/lore."
            display_text = ">> Auto-Play: Next Turn <<"
        else:
            user_text = self.entry_box.get().strip()
            display_text = user_text
            if not user_text: 
                self.send_btn.config(state="normal") 
                return
            
            self.entry_box.delete(0, 'end')
            self.entry_box.config(state="disabled")
            self.action_dropdown.config(state="disabled")
        
        roll_val = None
        message_for_ai = user_text
        
        if self.data.get("luck_mode"):
            if self.data.get("ai_control") or self.action_type_var.get() == "Do":
                roll_val = random.randint(1, 20)
                message_for_ai = f"{user_text} [Roll: {roll_val}/20]"

        self.append_text(display_text, is_player=True, roll=roll_val)
        self.append_text("SYSTEM: AI is thinking...", is_player=False, is_system=True)
        self.root.update()
        
        threading.Thread(target=self.send_to_ai, args=(message_for_ai,)).start()

    def send_to_ai(self, user_text):
        def reenable_ui():
            if self.data["current_hp"] > 0: 
                self.send_btn.config(state="normal")
                if not self.data.get("ai_control"):
                    self.entry_box.config(state="normal")
                    self.action_dropdown.config(state="normal")
                    self.entry_box.focus_set()

        try:
            # Tell the AI current level/XP behind the scenes to keep it contextual
            # We don't do this for the very first generated prompt to avoid confusing the setup
            if len(self.data["messages"]) > 2:
                system_update = f"[System Note: Player is currently Level {self.data['level']} with {self.data['xp']}/100 XP.]\n{user_text}"
            else:
                system_update = user_text
                
            self.data["messages"].append({"role": "user", "content": system_update})
            
            response = ollama.chat(model=self.data["model_name"], messages=self.data["messages"])
            ai_text = response['message']['content'].strip()

            # --- PARSE INVENTORY ---
            items_found = re.finditer(r'\[ITEM:\s*(.*?)\s*\|\s*([+-]?\d+)\]', ai_text)
            inventory_changed = False
            for match in items_found:
                item_name = match.group(1).strip()
                amount = int(match.group(2).strip())
                
                if item_name not in self.data["inventory"]:
                    self.data["inventory"][item_name] = 0
                
                self.data["inventory"][item_name] += amount
                
                if self.data["inventory"][item_name] <= 0:
                    del self.data["inventory"][item_name]
                    
                inventory_changed = True

            if inventory_changed:
                self.root.after(0, self.render_inventory)
            
            ai_text = re.sub(r'\[ITEM:\s*(.*?)\s*\|\s*([+-]?\d+)\]', '', ai_text).strip()

            # --- PARSE PARTY ADDITIONS ---
            match = re.search(r'\[ADD_PARTY:\s*(.*?)\s*\|\s*(.*?)\]', ai_text)
            if match:
                new_name = match.group(1).strip()
                new_personality = match.group(2).strip()
                ai_text = re.sub(r'\[ADD_PARTY:.*?\]', '', ai_text).strip()
                self.root.after(0, self.prompt_new_party_image, new_name, new_personality)

            # --- PARSE XP & LEVELING ---
            xp_found = re.finditer(r'\[XP:\s*\+?(\d+)\]', ai_text)
            xp_changed = False
            leveled_up = False
            for match in xp_found:
                amount = int(match.group(1).strip())
                self.data["xp"] += amount
                xp_changed = True
                
                while self.data["xp"] >= 100:
                    self.data["level"] += 1
                    self.data["xp"] -= 100
                    self.data["max_hp"] += 20  
                    self.data["current_hp"] = self.data["max_hp"] 
                    leveled_up = True

            ai_text = re.sub(r'\[XP:\s*\+?(\d+)\]', '', ai_text).strip()

            # --- PARSE HP CHANGES ---
            hp_found = re.finditer(r'\[HP:\s*([+-]?\d+)\]', ai_text)
            hp_changed = False
            took_damage = False
            for match in hp_found:
                amount = int(match.group(1).strip())
                self.data["current_hp"] += amount
                
                if amount < 0:
                    took_damage = True

                if self.data["current_hp"] > self.data["max_hp"]:
                    self.data["current_hp"] = self.data["max_hp"]
                    
                hp_changed = True

            ai_text = re.sub(r'\[HP:\s*([+-]?\d+)\]', '', ai_text).strip()

            self.data["messages"].append({"role": "assistant", "content": ai_text})

            self.text_area.config(state="normal")
            content = self.text_area.get("1.0", "end")
            content = content.replace("SYSTEM: AI is thinking...\n", "")
            self.text_area.delete("1.0", "end")
            self.text_area.insert("end", content)
            self.text_area.config(state="disabled")
            
            self.append_text(ai_text)
            
            if inventory_changed:
                self.append_text("*** Inventory Updated! ***", is_system=True)
                
            if hp_changed or xp_changed:
                self.root.after(0, lambda: self.update_vitals_display(took_damage, leveled_up))

        except Exception as e:
            self.append_text(f"[SYSTEM ERROR: {str(e)}]", is_system=True)
        finally:
            self.root.after(0, reenable_ui)

    def prompt_new_party_image(self, name, personality):
        messagebox.showinfo("New Party Member!", f"{name} has joined your party!\nPlease select an avatar for them.")
        filepath = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.gif")])
        if not filepath:
            filepath = "" 

        self.data["party"].append({
            "name": name,
            "personality": personality,
            "avatar_path": filepath
        })
        
        self.append_text(f"*** {name} joined the party! ***", is_system=True)
        self.render_party()

    def save_game(self):
        filepath = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON Files", "*.json")])
        if filepath:
            with open(filepath, 'w') as f:
                json.dump(self.data, f, indent=4)
            messagebox.showinfo("Saved", "Game saved successfully!")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Ollama RPG - The Director's Cut")
    root.geometry("1100x700")
    root.configure(bg=BG_COLOR)

    def launch_new_game(data):
        RPGGame(root, data, is_loaded=False)

    def launch_loaded_game(data):
        RPGGame(root, data, is_loaded=True)

    app = RPGSetup(root, launch_new_game, launch_loaded_game)
    root.mainloop()